import os
import numpy as np


def SpecifyBoundaryCondition(ProblemType,ProblemType_NoExactSolution,ProblemType_EquatorialWave):
    if ProblemType == 'Coastal_Kelvin_Wave':
        BoundaryCondition = 'NonPeriodic_x'
    elif ProblemType == 'Inertia_Gravity_Wave' or ProblemType == 'NonLinear_Manufactured_Solution':
        BoundaryCondition = 'Periodic'
    elif (ProblemType == 'Planetary_Rossby_Wave' or ProblemType == 'Topographic_Rossby_Wave' 
          or ProblemType_EquatorialWave):
        BoundaryCondition = 'NonPeriodic_y'
    elif ProblemType_NoExactSolution:
        BoundaryCondition = 'Radiation'
        # Choose the boundary condition to be 'Radiation' or 'Reflection' i.e. no normal flow at the solid boundary.
    else:
        BoundaryCondition = 'NonPeriodic_xy'
    return BoundaryCondition


def SpecifyDomainExtents(ProblemType,ProblemType_NoExactSolution,ProblemType_EquatorialWave):
    if ProblemType == 'Plane_Gaussian_Wave':
        lX = 2.0
    elif ProblemType == 'Coastal_Kelvin_Wave':
        lX = 5000.0*1000.0
    elif ProblemType == 'Inertia_Gravity_Wave' or ProblemType == 'NonLinear_Manufactured_Solution':
        lX = 10000.0*1000.0
    elif ProblemType == 'Planetary_Rossby_Wave' or ProblemType == 'Topographic_Rossby_Wave':    
        lX = 50.0*1000.0
    elif ProblemType_NoExactSolution:
        lX = 1000.0*1000.0
    elif ProblemType_EquatorialWave:
        lX = 17500.0*1000.0
    elif ProblemType == 'Barotropic_Tide':
        lX = 250.0*1000.0
    return lX


def GenerateConvergenceStudyMeshes(ProblemType):
    if (ProblemType == 'Coastal_Kelvin_Inertia_Gravity_Planetary_Rossby_Wave'
        or ProblemType == 'Coastal_Kelvin_Inertia_Gravity_Topographic_Rossby_Wave'):
        ProblemType_NoExactSolution = True
    else:
        ProblemType_NoExactSolution = False
    if (ProblemType == 'Equatorial_Kelvin_Wave' or ProblemType == 'Equatorial_Yanai_Wave' 
        or ProblemType == 'Equatorial_Rossby_Wave' or ProblemType == 'Equatorial_Inertia_Gravity_Wave'):
        ProblemType_EquatorialWave = True
    else:
        ProblemType_EquatorialWave = False
    BoundaryCondition = SpecifyBoundaryCondition(ProblemType,ProblemType_NoExactSolution,ProblemType_EquatorialWave)
    lX = SpecifyDomainExtents(ProblemType,ProblemType_NoExactSolution,ProblemType_EquatorialWave)
    nCellsX = np.array([64,96,144,216,324])
    Subscripts = ['64x64','96x96','144x144','216x216','324x324']
    nCases = len(nCellsX)
    for iCase in range(0,nCases):
        dcEdge = lX/float(nCellsX[iCase])
        if BoundaryCondition == 'Periodic':
            os.system("./planar_hex.py --nx %d --ny %d --dc %f -o base_mesh_%s.nc" 
                      %(nCellsX[iCase],nCellsX[iCase],dcEdge,Subscripts[iCase]))
            os.system("MpasMeshConverter.x base_mesh_%s.nc mesh_%s.nc" 
                      %(Subscripts[iCase],Subscripts[iCase]))
        elif BoundaryCondition == 'NonPeriodic_x':
            os.system("./planar_hex.py --nx %d --ny %d --npx --dc %f -o base_mesh_%s.nc" 
                      %(nCellsX[iCase],nCellsX[iCase],dcEdge,Subscripts[iCase]))
            os.system("MpasCellCuller.x base_mesh_%s.nc culled_mesh_%s.nc" 
                      %(Subscripts[iCase],Subscripts[iCase]))
            os.system("MpasMeshConverter.x culled_mesh_%s.nc mesh_%s.nc" 
                      %(Subscripts[iCase],Subscripts[iCase]))
        elif BoundaryCondition == 'NonPeriodic_y':
            os.system("./planar_hex.py --nx %d --ny %d --npy --dc %f -o base_mesh_%s.nc" 
                      %(nCellsX[iCase],nCellsX[iCase],dcEdge,Subscripts[iCase]))
            os.system("MpasCellCuller.x base_mesh_%s.nc culled_mesh_%s.nc" 
                      %(Subscripts[iCase],Subscripts[iCase]))
            os.system("MpasMeshConverter.x culled_mesh_%s.nc mesh_%s.nc" 
                      %(Subscripts[iCase],Subscripts[iCase]))
        elif BoundaryCondition == 'NonPeriodic_xy':
            os.system("./planar_hex.py --nx %d --ny %d --npx --npy --dc %f -o base_mesh_%s.nc" 
                      %(nCellsX[iCase],nCellsX[iCase],dcEdge,Subscripts[iCase]))
            os.system("MpasCellCuller.x base_mesh_%s.nc culled_mesh_%s.nc" 
                      %(Subscripts[iCase],Subscripts[iCase]))
            os.system("MpasMeshConverter.x culled_mesh_%s.nc mesh_%s.nc" 
                      %(Subscripts[iCase],Subscripts[iCase]))
        if not(BoundaryCondition == 'Periodic'):
            os.system("mv culled_graph.info culled_graph_%s.info" %(Subscripts[iCase]))
        os.system("mv graph.info graph_%s.info" %(Subscripts[iCase]))
    if not(BoundaryCondition == 'Periodic'):
        os.system("rm culled_graph_*.info")
    os.system("rm graph_*.info")

    
do_GenerateConvergenceStudyMeshes = True
if do_GenerateConvergenceStudyMeshes:
    ProblemType = 'Coastal_Kelvin_Wave'
    GenerateConvergenceStudyMeshes(ProblemType)
